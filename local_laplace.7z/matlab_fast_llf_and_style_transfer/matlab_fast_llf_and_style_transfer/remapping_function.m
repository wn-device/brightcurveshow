%This is just a toy example!
function y=remapping_function(x,g0)
sigma = 0.05;
step_vec =((0:8:255)-127)./128;
curve = [0,904,2119,4302,6701,9050,11358,13109,14702,16154,17673,19037,20365,21658,22910,24176,25402,26647,27948,29281,30695,32192,33770,35394,37104,38892,40791,42780,44864,47092,49517,52319];
curve_norm = curve./65535;
step_norm = (0:8:255)./255;
g0_shfit = interp1(step_norm,curve_norm-step_norm,g0);
g0_shfit = min(g0_shfit,0);
% curve_norm = curve./max(abs(curve))-0.5;
% y=(x-0.1).*(x>0.1)+(x+0.1).*(x<-0.1); %smoothing
%     y=3.*x.*(abs(x)<sigma)+(x+0.2).*(x>sigma)+(x-0.2).*(x<-sigma); %enhancement
%     y = (x<0).*(y-g0_shfit)+(x>0).*(y+g0_shfit);
%     y = interp1(step_vec,curve_norm,x+g0_shfit);

% % % % % % % % % % %  origin data
    i = x+g0;
    g0 = repmat(g0,[size(i,1) size(i,2) 1]);
    dnrm = sqrt(sum((i-g0).^2,3));
    unit = (i-g0)./repmat(eps + dnrm,[1 1 3]);
    % detail and edge processing
    rd = g0 + unit.*repmat(sigma*fd(dnrm/sigma),[1 1 3]);
    re = g0 + unit.*repmat((fe(dnrm - sigma) + sigma),[1 1 3]);
    % edge-detail separation based on sigma_r threshold
    isedge = repmat(dnrm > sigma,[1 1 3]);
    y = ~isedge.*rd + isedge.*re;

end
function out = fd(d)
    alpha = 0.25;
    sigma =2.5;
    noise_level = 0.01;
    out = d.^alpha;
    if alpha<1
        tau = smooth_step(noise_level,2*noise_level,d*sigma);
        out = tau.*out + (1-tau).*d;
    end
end
% smooth step edge between (xmin,0) and (xmax,1)
function y = smooth_step(xmin,xmax,x)
    y = (x - xmin)/(xmax - xmin);
    y = max(0,min(1,y));
    y = y.^2.*(y-2).^2;
end
% edge remapping function
function out = fe(a)
    beta = 1;
    out = beta*a;
end




