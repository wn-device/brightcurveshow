
function R=llf_irigin(I,r)
G = gaussian_pyramid(I);
L = laplacian_pyramid(zeros(size(I))); 
for lev0 = 1:length(L)-1
    for y0 = 1:size(G{lev0},1)
        for x0 = 1:size(G{lev0},2)
            g0 = G{lev0}(y0,x0,:);
            Iremap = r(I,g0);
            Lremap = laplacian_pyramid(Iremap,lev0+1);
            L{lev0}(y0,x0,:) = Lremap{lev0}(y0,x0,:);            
        end
    end
end
L{end} = G{end};
R = reconstruct_laplacian_pyramid(L);
end