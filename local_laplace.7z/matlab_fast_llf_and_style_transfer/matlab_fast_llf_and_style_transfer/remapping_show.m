x = -1:0.01:1;
figure,
for g0  =0.5
y = remapping_function(x,g0);
hold on,plot(x,y(1,:,1));
end
hold on,plot(x,x);

