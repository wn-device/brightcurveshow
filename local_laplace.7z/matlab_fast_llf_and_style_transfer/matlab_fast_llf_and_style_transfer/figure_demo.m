y_vec = 0:8:255;
data_size = 15;
dbstop if error
image_center = (data_size+1)/2;
sub_half_width = 1;
widthleft = image_center - sub_half_width;
withright = image_center + sub_half_width;
sub_val = round( y_vec(7)./ 255.*65535);
fpath = './inData/';
in_matrix = zeros(length(y_vec),data_size,data_size);
mean_var_matrix =zeros(length(y_vec),2);
matlab_matrix = zeros(length(y_vec),data_size,data_size);
for y_index = 1:length(y_vec)
 figure_template = ones(data_size,data_size);
y_vec_16bit =  round(y_vec(y_index)./ 255.*65535);
figure_template = figure_template.*y_vec_16bit;
figure_template(widthleft:withright,widthleft:withright) = sub_val;
filename = strcat(num2str(y_vec_16bit),'-',num2str(sub_val),'.tif');
in_matrix(y_index,:,:) = figure_template;
mean_val = mean(mean(figure_template));
mean_var_matrix(y_index,1) =mean_val;
mean_var_matrix(y_index,2) = std2(figure_template);
I = figure_template./65535;
N = 20;
% I_enhanced2=llf_general(I,@remapping_function,N);
I_enhanced2=llf_irigin(I,@remapping_function);
if size(I_enhanced2,3)>0
    I_enhanced2 = I_enhanced2(:,:,1);
end
% imwrite(uint16(figure_template),strcat(fpath,filename));
matlab_matrix(y_index,:,:) = round(I_enhanced2.*65535);
end

fpath_lr = './outData/';
lr_matrix = zeros(length(y_vec),data_size,data_size);
for y_index = 1:length(y_vec)
 y_vec_16bit =  round(y_vec(y_index)./ 255.*65535);
filename = strcat('20230401-',num2str(y_vec_16bit),'-',num2str(sub_val),'.tif');
lr_data = imread(strcat(fpath_lr,filename));
lr_data_one = lr_data(:,:,1);
lr_matrix(y_index,:,:) = lr_data_one;
end
figure,
for i = 1:image_center
hold on,plot(lr_matrix(:,i,i));
end
hold on,plot(in_matrix(:,3,3),'-k');
figure,
for i = 1:image_center
hold on,plot(lr_matrix(:,i,i) -mean_var_matrix(:,1));
end
figure,
for i = 1:image_center
hold on,plot(matlab_matrix(:,i,i));
end


